# Funil 2D — acabamento visual V6

Esta atualização é para quem já instalou a cena **Basquete 2D — Funil e Duas Cestas** e a atualização anterior **Chão, lava e barreira V5**.

O funil tem novos trilhos metálicos com iluminação azul. A rampa recebeu um acabamento mais encorpado e detalhes no eixo. As duas cestas ganharam novos aros e redes, além de tabelas, colunas e bases redesenhadas no estilo de metal e neon da arena. A lateral do funil continua aberta.

As novas peças são visuais. Os pontos de colisão, a pontuação, o movimento da alavanca, a barreira, a lava e o chão continuam usando as mesmas regras da V5.

## Instalação

1. Feche o Unity e extraia `Basquete2D_Funil_VisualV6.zip`.
2. Copie a pasta **Assets** extraída para a raiz do projeto NBA, juntando as pastas e substituindo os arquivos incluídos, inclusive os arquivos `.meta`.
3. Abra o projeto, espere o Unity importar as imagens e compilar os scripts. Use **Tools > Basquete 2D > Abrir funil de duas cestas**.
4. Selecione `MarbleBasketFunil2D`. No Inspector, confira a mensagem **Acabamento visual V6** e dê **Play**.

O pacote não substitui a cena `.unity`, o fundo da arena nem a imagem existente da alavanca. Os nomes, quantidade de bolinhas, duração e demais opções já salvas na cena são preservados.

## Verificações e limites

Os métodos de física, colisão, movimentação, pontuação, lava e barreira foram comparados com a V5; seus cálculos e colisores foram preservados. Os scripts de runtime compilaram sem erros ou avisos com assemblies de referência da Unity 2021.3.33, e os novos arquivos de imagem têm transparência.

O Unity Editor não está disponível neste ambiente. A compilação na Unity 6000.4.11f1 e o acabamento durante o Play ainda precisam ser conferidos no seu projeto. Foi feita uma prévia aproximada para verificar o encaixe dos elementos, mas ela não substitui o Play no Unity.
